package particle.fx.particle;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1667;
import net.minecraft.class_1676;
import net.minecraft.class_1682;
import net.minecraft.class_1685;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class ParticleSystem {
	private static final ParticleSystem INSTANCE = new ParticleSystem();
	private static final class_310 CLIENT = class_310.method_1551();
	private static final int TOTEM_DURATION = 20;
	private static final float GRAVITY_STRENGTH = 0.04F;
	private static final double WORLD_MIN_RADIUS = 3.0;
	private static final double WORLD_MAX_RADIUS = 60.0;
	private static final double WORLD_MAX_HEIGHT = 25.0;
	private static final double WORLD_DESPAWN_DISTANCE = 65.0;
	private static final int[] RANDOM_COLORS = {
			0xFFFF0000,
			0xFFFF7F00,
			0xFFFFFF00,
			0xFF00FF00,
			0xFF00FFFF,
			0xFF0000FF,
			0xFF8B00FF,
			0xFFFF00FF,
			0xFFFF1493,
			0xFFFFFFFF,
			0xFF00FF7F,
			0xFFFF6347
	};

	private final List<Particle3D> particles = new ArrayList<>();
	private final List<Particle3D> worldParticles = new ArrayList<>();
	private final List<TotemEmitter> totemEmitters = new ArrayList<>();
	private final Settings settings = new Settings();
	private float walkParticleAccumulator;
	private class_243 lastPlayerPos = class_243.field_1353;
	private class_243 playerVelocity = class_243.field_1353;
	private double playerSpeed;
	private long lastWorldSpawnTime;

	private ParticleSystem() {
	}

	public static ParticleSystem getInstance() {
		return INSTANCE;
	}

	public Settings getSettings() {
		return settings;
	}

	public void tick(class_310 client) {
		if (!settings.enabled || client.field_1724 == null || client.field_1687 == null) {
			clear();
			return;
		}

		if (settings.walkTrigger) {
			handleWalkParticles(client);
		} else {
			walkParticleAccumulator = 0.0F;
		}

		if (settings.projectileTrigger) {
			handleProjectileParticles(client);
		}

		handleTotemEmitters();
		handleWorldParticles(client);
		updateParticles(particles);
		updateParticles(worldParticles);
	}

	public void spawnAttackParticles(class_1297 target) {
		if (!settings.enabled || !settings.attackTrigger || target == null) {
			return;
		}

		float spreadValue = settings.spread * 0.15F;
		for (int i = 0; i < settings.attackAmount; i++) {
			class_243 position = new class_243(
					target.method_23317(),
					target.method_23318() + Math.random() * target.method_17682(),
					target.method_23321()
			);
			class_243 velocity = new class_243(
					(Math.random() - 0.5) * 2.0 * spreadValue * settings.speed,
					(Math.random() - 0.5) * 2.0 * spreadValue * settings.speed,
					(Math.random() - 0.5) * 2.0 * spreadValue * settings.speed
			);

			particles.add(createParticle(position, velocity, settings.size, settings.lifeTime));
		}
	}

	public void spawnTotemParticles(class_1297 entity) {
		if (settings.enabled && settings.totemTrigger && entity != null) {
			totemEmitters.add(new TotemEmitter(entity, TOTEM_DURATION));
		}
	}

	public void render(WorldRenderContext context) {
		if ((particles.isEmpty() && worldParticles.isEmpty()) || CLIENT.field_1724 == null || CLIENT.field_1687 == null) {
			return;
		}

		class_4587 matrices = context.matrices();
		class_4597.class_4598 immediate = CLIENT.method_22940().method_23000();
		float tickDelta = CLIENT.method_61966().method_60637(true);

		for (Particle3D particle : particles) {
			particle.render(matrices, immediate, settings.glowSize, tickDelta);
		}

		for (Particle3D particle : worldParticles) {
			particle.render(matrices, immediate, settings.worldGlowSize, tickDelta);
		}

		immediate.method_22993();
	}

	private void clear() {
		particles.clear();
		worldParticles.clear();
		totemEmitters.clear();
		walkParticleAccumulator = 0.0F;
		lastPlayerPos = class_243.field_1353;
		playerVelocity = class_243.field_1353;
		playerSpeed = 0.0;
	}

	private void handleWalkParticles(class_310 client) {
		double velocitySq = client.field_1724.method_18798().method_1027();
		boolean isMoving = velocitySq > 0.0001 && !client.field_1724.method_5715();

		if (!isMoving) {
			walkParticleAccumulator = 0.0F;
			return;
		}

		float particlesPerTick = settings.walkAmount / 20.0F;
		walkParticleAccumulator += particlesPerTick;
		int particlesToSpawn = (int) walkParticleAccumulator;
		walkParticleAccumulator -= particlesToSpawn;

		if (particlesToSpawn <= 0) {
			return;
		}

		float yaw = client.field_1724.method_36454();
		double radians = Math.toRadians(yaw + 90.0F);
		double offsetX = Math.cos(radians) * 0.5;
		double offsetZ = Math.sin(radians) * 0.5;
		float spreadValue = settings.spread * 0.05F;

		for (int i = 0; i < particlesToSpawn; i++) {
			class_243 position = new class_243(
					client.field_1724.method_23317() - offsetX + (Math.random() - 0.5) * 0.3,
					client.field_1724.method_23318() + 0.3 + Math.random() * (client.field_1724.method_17682() - 0.3),
					client.field_1724.method_23321() - offsetZ + (Math.random() - 0.5) * 0.3
			);
			class_243 velocity = new class_243(
					(Math.random() - 0.5) * spreadValue * settings.speed,
					(Math.random() - 0.5) * spreadValue * 0.5 * settings.speed,
					(Math.random() - 0.5) * spreadValue * settings.speed
			);

			particles.add(createParticle(position, velocity, settings.size * 0.6F, settings.lifeTime * 0.5F));
		}
	}

	private void handleProjectileParticles(class_310 client) {
		float spreadValue = settings.spread * 0.03F;

		for (class_1297 entity : client.field_1687.method_18112()) {
			if (!(entity instanceof class_1682 || entity instanceof class_1667 || entity instanceof class_1685)) {
				continue;
			}

			class_1676 projectile = (class_1676) entity;
			boolean isMoving = Math.abs(projectile.method_23317() - projectile.field_6014) > 0.01
					|| Math.abs(projectile.method_23318() - projectile.field_6036) > 0.01
					|| Math.abs(projectile.method_23321() - projectile.field_5969) > 0.01;

			if (!isMoving && projectile.method_18798().method_1027() <= 0.01) {
				continue;
			}

			for (int i = 0; i < 2; i++) {
				class_243 position = new class_243(
						projectile.method_23317() + (Math.random() - 0.5) * 0.5,
						projectile.method_23318() + Math.random() * projectile.method_17682(),
						projectile.method_23321() + (Math.random() - 0.5) * 0.5
				);
				class_243 velocity = new class_243(
						(Math.random() - 0.5) * 2.0 * spreadValue * settings.speed,
						(Math.random() - 0.5) * 2.0 * spreadValue * settings.speed,
						(Math.random() - 0.5) * 2.0 * spreadValue * settings.speed
				);

				particles.add(createParticle(position, velocity, settings.size * 0.5F, settings.lifeTime * 0.3F));
			}
		}
	}

	private void handleTotemEmitters() {
		Iterator<TotemEmitter> iterator = totemEmitters.iterator();
		while (iterator.hasNext()) {
			TotemEmitter emitter = iterator.next();
			emitter.tick();

			if (emitter.isAlive()) {
				spawnTotemBurst(emitter.getEntity(), emitter.getProgress());
			} else {
				iterator.remove();
			}
		}
	}

	private void handleWorldParticles(class_310 client) {
		if (!settings.worldParticles) {
			worldParticles.clear();
			lastPlayerPos = class_243.field_1353;
			playerVelocity = class_243.field_1353;
			playerSpeed = 0.0;
			return;
		}

		class_243 currentPos = client.field_1724.method_73189();
		if (lastPlayerPos != class_243.field_1353) {
			playerVelocity = currentPos.method_1020(lastPlayerPos);
			playerSpeed = playerVelocity.method_37267();
		}
		lastPlayerPos = currentPos;

		double despawnDistanceSq = WORLD_DESPAWN_DISTANCE * WORLD_DESPAWN_DISTANCE;
		Iterator<Particle3D> iterator = worldParticles.iterator();
		while (iterator.hasNext()) {
			Particle3D particle = iterator.next();
			if (particle.getHorizontalDistanceSquaredTo(currentPos) > despawnDistanceSq) {
				iterator.remove();
			}
		}

		int delay = calculateWorldSpawnDelay(playerSpeed);
		long now = System.currentTimeMillis();
		if (worldParticles.size() >= settings.worldAmount || now - lastWorldSpawnTime < delay) {
			return;
		}

		int spawnCount = calculateWorldSpawnCount(playerSpeed, worldParticles.size(), settings.worldAmount);
		for (int i = 0; i < spawnCount && worldParticles.size() < settings.worldAmount; i++) {
			worldParticles.add(createWorldParticle(currentPos));
		}

		lastWorldSpawnTime = now;
	}

	private void updateParticles(List<Particle3D> targetParticles) {
		Iterator<Particle3D> iterator = targetParticles.iterator();
		while (iterator.hasNext()) {
			Particle3D particle = iterator.next();
			particle.update();

			if (particle.isDead()) {
				iterator.remove();
			}
		}
	}

	private void spawnTotemBurst(class_1297 entity, float progress) {
		if (entity == null || entity.method_31481()) {
			return;
		}

		float spreadMultiplier = 1.0F - progress * 0.5F;
		for (int i = 0; i < 4; i++) {
			double x = Math.random() * 2.0 - 1.0;
			double y = Math.random() * 2.0 - 1.0;
			double z = Math.random() * 2.0 - 1.0;

			if (x * x + y * y + z * z > 1.0) {
				continue;
			}

			class_243 position = new class_243(
					entity.method_23317() + x * entity.method_17681() * 0.5,
					entity.method_23323(0.5) + y * entity.method_17682() * 0.5,
					entity.method_23321() + z * entity.method_17681() * 0.5
			);
			double velocityScale = settings.spread * 0.18 * spreadMultiplier * settings.speed;
			double upward = Math.random() < 0.4
					? (0.15 + Math.random() * 0.2) * settings.speed
					: (0.03 + Math.random() * 0.07) * settings.speed;
			class_243 velocity = new class_243(x * velocityScale, upward, z * velocityScale);
			particles.add(createParticle(position, velocity, settings.size * 0.8F, settings.lifeTime * 0.8F, getTotemColor()));
		}
	}

	private Particle3D createParticle(class_243 position, class_243 velocity, float size, float lifeTime) {
		return createParticle(position, velocity, size, lifeTime, getParticleColor());
	}

	private Particle3D createParticle(class_243 position, class_243 velocity, float size, float lifeTime, int color) {
		return new Particle3D(position, velocity, color, size, lifeTime)
				.setGravity(getGravity())
				.setVelocityMultiplier(0.99F)
				.setMode(settings.particleMode)
				.setGlowMode(settings.glowMode);
	}

	private Particle3D createWorldParticle(class_243 playerPos) {
		double radius = WORLD_MIN_RADIUS + Math.random() * (WORLD_MAX_RADIUS - WORLD_MIN_RADIUS);
		double angle = Math.random() * Math.PI * 2.0;
		double spawnX = playerPos.field_1352;
		double spawnZ = playerPos.field_1350;

		if (playerSpeed > 0.05 && playerVelocity.method_37267() > 0.01) {
			class_243 normalizedVelocity = playerVelocity.method_1029();
			double forwardAngle = Math.atan2(normalizedVelocity.field_1350, normalizedVelocity.field_1352);
			double angleSpread = Math.PI * 0.4;
			angle = forwardAngle + (Math.random() - 0.5) * angleSpread * 2.0;
			double forwardOffset = radius * 0.7 * Math.min(playerSpeed * 8.0, 1.0);
			spawnX += normalizedVelocity.field_1352 * forwardOffset;
			spawnZ += normalizedVelocity.field_1350 * forwardOffset;
		}

		class_243 position = new class_243(
				spawnX + Math.cos(angle) * radius,
				playerPos.field_1351 - 5.0 + Math.random() * WORLD_MAX_HEIGHT,
				spawnZ + Math.sin(angle) * radius
		);
		class_243 velocity = new class_243(
				(Math.random() - 0.5) * 0.08,
				(Math.random() - 0.5) * 0.02,
				(Math.random() - 0.5) * 0.08
		);

		float gravity = settings.worldPhysics ? 0.0002F : 0.0F;
		return new Particle3D(position, velocity, getParticleColor(), settings.worldSize, settings.worldLifeTime)
				.setGravity(gravity)
				.setVelocityMultiplier(0.99F)
				.setMode(settings.worldMode)
				.setGlowMode(settings.glowMode)
				.setCollision(settings.worldPhysics);
	}

	private static int calculateWorldSpawnDelay(double playerSpeed) {
		int baseDelay = 40;
		if (playerSpeed <= 0.05) {
			return baseDelay;
		}

		double speedFactor = Math.min(playerSpeed * 5.0, 4.0);
		return Math.max((int) (baseDelay / (1.0 + speedFactor)), 8);
	}

	private static int calculateWorldSpawnCount(double playerSpeed, int currentCount, int maxCount) {
		int spawnCount = 1;
		if (playerSpeed > 0.1) {
			spawnCount = (int) Math.min(8, maxCount - currentCount);
			spawnCount = Math.max(1, (int) (spawnCount * Math.min(playerSpeed * 5.0, 1.0)));
		}
		return spawnCount;
	}

	private int getParticleColor() {
		if (settings.randomColor) {
			return RANDOM_COLORS[ThreadLocalRandom.current().nextInt(RANDOM_COLORS.length)];
		}

		return settings.color;
	}

	private int getTotemColor() {
		int[] totemColors = {
				0xFF7CFC00,
				0xFFFFD700,
				0xFF32CD32,
				0xFFFFA500,
				0xFF00FF00,
				0xFFADFF2F
		};
		return totemColors[ThreadLocalRandom.current().nextInt(totemColors.length)];
	}

	private float getGravity() {
		return (1.0F - 0.9F) * GRAVITY_STRENGTH;
	}

	public static final class Settings {
		public boolean enabled = true;
		public boolean attackTrigger = true;
		public boolean totemTrigger = true;
		public boolean walkTrigger = true;
		public boolean projectileTrigger = true;
		public boolean worldParticles = true;
		public boolean worldPhysics = false;
		public boolean randomColor = false;
		public Particle3D.ParticleMode particleMode = Particle3D.ParticleMode.STAR;
		public Particle3D.ParticleMode worldMode = Particle3D.ParticleMode.STAR;
		public Particle3D.GlowMode glowMode = Particle3D.GlowMode.BOTH;
		public int attackAmount = 40;
		public int walkAmount = 30;
		public int worldAmount = 100;
		public float spread = 1.0F;
		public float speed = 2.0F;
		public float lifeTime = 2.5F;
		public float size = 1.0F;
		public float glowSize = 7.5F;
		public float worldLifeTime = 10.0F;
		public float worldSize = 1.5F;
		public float worldGlowSize = 3.0F;
		public int color = 0xFF896148;

		public void reset() {
			enabled = true;
			attackTrigger = true;
			totemTrigger = true;
			walkTrigger = true;
			projectileTrigger = true;
			worldParticles = true;
			worldPhysics = false;
			randomColor = false;
			particleMode = Particle3D.ParticleMode.STAR;
			worldMode = Particle3D.ParticleMode.STAR;
			glowMode = Particle3D.GlowMode.BOTH;
			attackAmount = 40;
			walkAmount = 30;
			worldAmount = 100;
			spread = 1.0F;
			speed = 2.0F;
			lifeTime = 2.5F;
			size = 1.0F;
			glowSize = 7.5F;
			worldLifeTime = 10.0F;
			worldSize = 1.5F;
			worldGlowSize = 3.0F;
			color = 0xFF896148;
		}
	}
}
