package particle.fx.particle;

import net.minecraft.class_4588;
import org.joml.Matrix4f;

final class ParticleRenderer {
	private ParticleRenderer() {
	}

	static void drawCube(class_4588 buffer, Matrix4f matrix, int color, float size) {
		float half = size / 2.0F;
		int r = color >> 16 & 0xFF;
		int g = color >> 8 & 0xFF;
		int b = color & 0xFF;
		int a = color >> 24 & 0xFF;

		buffer.method_22918(matrix, -half, half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, -half, half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, half, -half).method_1336(r, g, b, a);

		buffer.method_22918(matrix, -half, -half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, -half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, -half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, -half, -half, half).method_1336(r, g, b, a);

		buffer.method_22918(matrix, -half, half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, -half, -half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, -half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, half, half).method_1336(r, g, b, a);

		buffer.method_22918(matrix, -half, half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, -half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, -half, -half, -half).method_1336(r, g, b, a);

		buffer.method_22918(matrix, -half, half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, -half, -half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, -half, -half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, -half, half, half).method_1336(r, g, b, a);

		buffer.method_22918(matrix, half, half, -half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, -half, half).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, -half, -half).method_1336(r, g, b, a);
	}

	static void drawLines(class_4588 buffer, Matrix4f matrix, int color, float size) {
		float half = size / 2.0F;
		int r = color >> 16 & 0xFF;
		int g = color >> 8 & 0xFF;
		int b = color & 0xFF;
		int a = color >> 24 & 0xFF;

		line(buffer, matrix, -half, -half, -half, half, -half, -half, r, g, b, a);
		line(buffer, matrix, half, -half, -half, half, -half, half, r, g, b, a);
		line(buffer, matrix, half, -half, half, -half, -half, half, r, g, b, a);
		line(buffer, matrix, -half, -half, half, -half, -half, -half, r, g, b, a);
		line(buffer, matrix, -half, half, -half, half, half, -half, r, g, b, a);
		line(buffer, matrix, half, half, -half, half, half, half, r, g, b, a);
		line(buffer, matrix, half, half, half, -half, half, half, r, g, b, a);
		line(buffer, matrix, -half, half, half, -half, half, -half, r, g, b, a);
		line(buffer, matrix, -half, -half, -half, -half, half, -half, r, g, b, a);
		line(buffer, matrix, half, -half, -half, half, half, -half, r, g, b, a);
		line(buffer, matrix, half, -half, half, half, half, half, r, g, b, a);
		line(buffer, matrix, -half, -half, half, -half, half, half, r, g, b, a);
	}

	private static void line(class_4588 buffer, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, int r, int g, int b, int a) {
		buffer.method_22918(matrix, x1, y1, z1).method_1336(r, g, b, a);
		buffer.method_22918(matrix, x2, y2, z2).method_1336(r, g, b, a);
	}

	static void drawGlow(class_4588 buffer, Matrix4f matrix, int color, int alpha, float size) {
		int r = color >> 16 & 0xFF;
		int g = color >> 8 & 0xFF;
		int b = color & 0xFF;
		float half = size / 2.0F;

		buffer.method_22918(matrix, -half, -half, 0).method_22913(0, 0).method_1336(r, g, b, alpha);
		buffer.method_22918(matrix, -half, half, 0).method_22913(0, 1).method_1336(r, g, b, alpha);
		buffer.method_22918(matrix, half, half, 0).method_22913(1, 1).method_1336(r, g, b, alpha);
		buffer.method_22918(matrix, half, -half, 0).method_22913(1, 0).method_1336(r, g, b, alpha);
	}
}
