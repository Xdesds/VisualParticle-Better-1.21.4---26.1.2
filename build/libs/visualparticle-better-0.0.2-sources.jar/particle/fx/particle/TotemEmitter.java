package particle.fx.particle;

import net.minecraft.class_1297;

final class TotemEmitter {
	private final class_1297 entity;
	private final int maxAge;
	private int age;

	TotemEmitter(class_1297 entity, int maxAge) {
		this.entity = entity;
		this.maxAge = maxAge;
	}

	void tick() {
		age++;
	}

	boolean isAlive() {
		return age < maxAge && entity != null && !entity.method_31481();
	}

	class_1297 getEntity() {
		return entity;
	}

	float getProgress() {
		return (float) age / (float) maxAge;
	}
}
