package particle.fx.particle;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import particle.fx.ParticleFxMod;

import java.util.function.Function;
import net.minecraft.class_10799;
import net.minecraft.class_12247;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;

final class ParticleRenderLayers {
	private static final RenderPipeline COLOR_PIPELINE = class_10799.method_67887(
			RenderPipeline.builder(class_10799.field_56860)
					.withLocation(class_2960.method_60655(ParticleFxMod.MOD_ID, "world_particles_color"))
					.withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
					.withCull(false)
					.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
					.withDepthWrite(false)
					.withBlend(BlendFunction.LIGHTNING)
					.build()
	);

	private static final RenderPipeline LINES_PIPELINE = class_10799.method_67887(
			RenderPipeline.builder(class_10799.field_56860)
					.withLocation(class_2960.method_60655(ParticleFxMod.MOD_ID, "world_particles_lines"))
					.withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_29344)
					.withCull(false)
					.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
					.withDepthWrite(false)
					.withBlend(BlendFunction.LIGHTNING)
					.build()
	);

	private static final RenderPipeline GLOW_PIPELINE = class_10799.method_67887(
			RenderPipeline.builder(class_10799.field_56864)
					.withLocation(class_2960.method_60655(ParticleFxMod.MOD_ID, "world_particles_glow"))
					.withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
					.withCull(false)
					.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
					.withDepthWrite(false)
					.withBlend(BlendFunction.LIGHTNING)
					.withSampler("Sampler0")
					.build()
	);

	static final class_1921 QUADS = class_1921.method_75940(
			ParticleFxMod.MOD_ID + "_world_particles_cube",
			class_12247.method_75927(COLOR_PIPELINE)
					.method_75937()
					.method_75929(2048)
					.method_75938()
	);

	static final class_1921 LINES = class_1921.method_75940(
			ParticleFxMod.MOD_ID + "_world_particles_lines",
			class_12247.method_75927(LINES_PIPELINE)
					.method_75937()
					.method_75929(2048)
					.method_75938()
	);

	static final Function<class_2960, class_1921> GLOW = class_156.method_34866(texture -> {
		class_12247 setup = class_12247.method_75927(GLOW_PIPELINE)
				.method_75934("Sampler0", texture)
				.method_75937()
				.method_75929(2048)
				.method_75938();
		return class_1921.method_75940(ParticleFxMod.MOD_ID + "_world_particles_glow", setup);
	});

	private ParticleRenderLayers() {
	}
}
