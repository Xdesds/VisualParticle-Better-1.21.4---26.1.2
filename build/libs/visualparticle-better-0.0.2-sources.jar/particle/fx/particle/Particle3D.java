package particle.fx.particle;

import org.joml.Matrix4f;
import particle.fx.ParticleFxMod;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;

final class Particle3D {
	enum ParticleMode {
		CUBES,
		CROWN,
		CUBE_BLAST,
		DOLLAR,
		HEART,
		LIGHTNING,
		LINE,
		RHOMBUS,
		SNOWFLAKE,
		STAR,
		STAR_ALT,
		TRIANGLE,
		RANDOM
	}

	enum GlowMode {
		BLOOM,
		BLOOM_SAMPLE,
		BOTH
	}

	private static final class_310 CLIENT = class_310.method_1551();
	private static final int FADE_IN_MS = 150;
	private static final int FADE_OUT_MS = 250;
	private static final ParticleMode[] RANDOM_MODES = {
			ParticleMode.CUBES,
			ParticleMode.CROWN,
			ParticleMode.CUBE_BLAST,
			ParticleMode.DOLLAR,
			ParticleMode.HEART,
			ParticleMode.LIGHTNING,
			ParticleMode.LINE,
			ParticleMode.RHOMBUS,
			ParticleMode.SNOWFLAKE,
			ParticleMode.STAR,
			ParticleMode.STAR_ALT,
			ParticleMode.TRIANGLE
	};

	private static final class_2960 TEXTURE_CROWN = texture("crown.png");
	private static final class_2960 TEXTURE_CUBE_BLAST = texture("cubeblast1.png");
	private static final class_2960 TEXTURE_DOLLAR = texture("dollar.png");
	private static final class_2960 TEXTURE_HEART = texture("heart.png");
	private static final class_2960 TEXTURE_LIGHTNING = texture("lightning.png");
	private static final class_2960 TEXTURE_LINE = texture("line.png");
	private static final class_2960 TEXTURE_RHOMBUS = texture("rhombus.png");
	private static final class_2960 TEXTURE_SNOWFLAKE = texture("snowflake.png");
	private static final class_2960 TEXTURE_STAR = texture("star.png");
	private static final class_2960 TEXTURE_STAR_ALT = texture("star1.png");
	private static final class_2960 TEXTURE_TRIANGLE = texture("triangle.png");
	private static final class_2960 GLOW_BLOOM = texture("dashbloom.png");
	private static final class_2960 GLOW_BLOOM_SAMPLE = texture("dashbloomsample.png");

	private double x;
	private double y;
	private double z;
	private double lastX;
	private double lastY;
	private double lastZ;
	private double velocityX;
	private double velocityY;
	private double velocityZ;
	private final long startTime;
	private long fadeOutStart = -1L;
	private final float phase;
	private final int color;
	private final float scale;
	private final long lifeTimeMs;
	private float rotation;
	private float gravityStrength = 0.004F;
	private float velocityMultiplier = 0.99F;
	private boolean collidesWithWorld = true;
	private ParticleMode actualMode = ParticleMode.CUBES;
	private GlowMode glowMode = GlowMode.BOTH;
	private boolean spinning = true;

	Particle3D(class_243 position, class_243 velocity, int color, float scale, float maxAgeSeconds) {
		this.startTime = System.currentTimeMillis();
		this.phase = (float) (Math.random() * 100.0);
		this.rotation = (float) (Math.random() * 360.0);
		this.x = position.field_1352;
		this.y = position.field_1351;
		this.z = position.field_1350;
		this.lastX = position.field_1352;
		this.lastY = position.field_1351;
		this.lastZ = position.field_1350;
		this.velocityX = velocity.field_1352;
		this.velocityY = velocity.field_1351;
		this.velocityZ = velocity.field_1350;
		this.color = color;
		this.scale = scale;
		this.lifeTimeMs = (long) (maxAgeSeconds * 1000.0F);
	}

	Particle3D setGravity(float gravity) {
		this.gravityStrength = gravity;
		return this;
	}

	Particle3D setVelocityMultiplier(float multiplier) {
		this.velocityMultiplier = multiplier;
		return this;
	}

	Particle3D setCollision(boolean collision) {
		this.collidesWithWorld = collision;
		return this;
	}

	Particle3D setMode(ParticleMode mode) {
		if (mode == ParticleMode.RANDOM) {
			this.actualMode = RANDOM_MODES[ThreadLocalRandom.current().nextInt(RANDOM_MODES.length)];
		} else {
			this.actualMode = mode;
		}
		return this;
	}

	Particle3D setGlowMode(GlowMode glowMode) {
		this.glowMode = glowMode;
		return this;
	}

	Particle3D setSpinning(boolean spinning) {
		this.spinning = spinning;
		return this;
	}

	void update() {
		long now = System.currentTimeMillis();
		this.lastX = this.x;
		this.lastY = this.y;
		this.lastZ = this.z;

		this.velocityY -= gravityStrength;

		if (collidesWithWorld && CLIENT.field_1687 != null) {
			if (isHit(this.x + this.velocityX, this.y, this.z)) {
				this.velocityX *= -0.8;
			} else {
				this.x += this.velocityX;
			}

			if (isHit(this.x, this.y + this.velocityY, this.z)) {
				this.velocityX *= 0.999;
				this.velocityZ *= 0.999;
				this.velocityY *= -0.7;
			} else {
				this.y += this.velocityY;
			}

			if (isHit(this.x, this.y, this.z + this.velocityZ)) {
				this.velocityZ *= -0.8;
			} else {
				this.z += this.velocityZ;
			}
		} else {
			this.x += this.velocityX;
			this.y += this.velocityY;
			this.z += this.velocityZ;
		}

		this.velocityX *= velocityMultiplier;
		this.velocityY *= velocityMultiplier;
		this.velocityZ *= velocityMultiplier;

		if (spinning) {
			this.rotation += 2.0F;
		}

		if (fadeOutStart < 0L && now - startTime > lifeTimeMs) {
			fadeOutStart = now;
		}
	}

	boolean isDead() {
		return fadeOutStart >= 0L && getAlpha(System.currentTimeMillis()) <= 0.001F;
	}

	double getHorizontalDistanceSquaredTo(class_243 position) {
		double dx = this.x - position.field_1352;
		double dz = this.z - position.field_1350;
		return dx * dx + dz * dz;
	}

	void render(class_4587 matrices, class_4597 vertexConsumers, float glowSize, float tickDelta) {
		long now = System.currentTimeMillis();
		float alpha = getAlpha(now);
		if (alpha <= 0.0F || CLIENT.field_1773 == null) {
			return;
		}

		class_243 cameraPos = CLIENT.field_1773.method_19418().method_71156();
		float cameraYaw = CLIENT.field_1773.method_19418().method_19330();
		float cameraPitch = CLIENT.field_1773.method_19418().method_19329();

		double interpX = class_3532.method_16436(tickDelta, this.lastX, this.x);
		double interpY = class_3532.method_16436(tickDelta, this.lastY, this.y);
		double interpZ = class_3532.method_16436(tickDelta, this.lastZ, this.z);

		float relX = (float) (interpX - cameraPos.field_1352);
		float relY = (float) (interpY - cameraPos.field_1351);
		float relZ = (float) (interpZ - cameraPos.field_1350);

		if (actualMode == ParticleMode.CUBES) {
			renderCube(matrices, vertexConsumers, relX, relY, relZ, alpha, glowSize, cameraYaw, cameraPitch);
		} else {
			renderTextured(matrices, vertexConsumers, relX, relY, relZ, alpha, glowSize, cameraYaw, cameraPitch);
		}
	}

	private float getAlpha(long now) {
		float fadeIn = ease(clamp((now - startTime) / (float) FADE_IN_MS));
		if (fadeOutStart < 0L) {
			return fadeIn;
		}

		float fadeOut = 1.0F - ease(clamp((now - fadeOutStart) / (float) FADE_OUT_MS));
		return Math.min(fadeIn, fadeOut);
	}

	private static float ease(float value) {
		if (value < 0.5F) {
			return 2.0F * value * value;
		}
		return 1.0F - (float) Math.pow(-2.0F * value + 2.0F, 2.0F) / 2.0F;
	}

	private static float clamp(float value) {
		return Math.max(0.0F, Math.min(1.0F, value));
	}

	private boolean isHit(double x, double y, double z) {
		if (CLIENT.field_1687 == null) {
			return false;
		}

		class_2338 pos = class_2338.method_49637(x, y, z);
		return CLIENT.field_1687.method_8320(pos).method_26234(CLIENT.field_1687, pos);
	}

	private class_2960 getTexture() {
		return switch (actualMode) {
			case CROWN -> TEXTURE_CROWN;
			case CUBE_BLAST -> TEXTURE_CUBE_BLAST;
			case DOLLAR -> TEXTURE_DOLLAR;
			case HEART -> TEXTURE_HEART;
			case LIGHTNING -> TEXTURE_LIGHTNING;
			case LINE -> TEXTURE_LINE;
			case RHOMBUS -> TEXTURE_RHOMBUS;
			case SNOWFLAKE -> TEXTURE_SNOWFLAKE;
			case STAR -> TEXTURE_STAR;
			case STAR_ALT -> TEXTURE_STAR_ALT;
			case TRIANGLE -> TEXTURE_TRIANGLE;
			default -> null;
		};
	}

	private static class_2960 texture(String fileName) {
		return class_2960.method_60655(ParticleFxMod.MOD_ID, "textures/world/" + fileName);
	}

	private void renderCube(class_4587 matrices, class_4597 vertexConsumers, float relX, float relY, float relZ, float alpha, float glowSize, float cameraYaw, float cameraPitch) {
		long now = System.currentTimeMillis();
		float rotationAnim = (float) (now % 9000L) / 9000.0F * 360.0F;
		int glowColor = ColorUtil.withAlpha(color, alpha);
		float cubeSize = scale * 0.25F;
		float cubeGlow1 = cubeSize * glowSize;
		float cubeGlow2 = cubeSize * (glowSize / 3.0F);

		matrices.method_22903();
		matrices.method_46416(relX, relY, relZ);
		matrices.method_22907(class_7833.field_40716.rotationDegrees(rotationAnim + this.phase));
		matrices.method_22907(class_7833.field_40714.rotationDegrees(rotationAnim * 0.5F));
		Matrix4f matrix = matrices.method_23760().method_23761();
		ParticleRenderer.drawCube(vertexConsumers.method_73477(ParticleRenderLayers.QUADS), matrix, ColorUtil.withAlpha(color, alpha * 0.2F), cubeSize);
		ParticleRenderer.drawLines(vertexConsumers.method_73477(ParticleRenderLayers.LINES), matrix, ColorUtil.withAlpha(color, alpha * 0.4F), cubeSize);
		matrices.method_22909();

		matrices.method_22903();
		matrices.method_46416(relX, relY, relZ);
		matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
		matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
		Matrix4f glowMatrix = matrices.method_23760().method_23761();
		renderGlow(vertexConsumers, glowMatrix, glowColor, alpha, cubeGlow1, cubeGlow2);
		matrices.method_22909();
	}

	private void renderTextured(class_4587 matrices, class_4597 vertexConsumers, float relX, float relY, float relZ, float alpha, float glowSize, float cameraYaw, float cameraPitch) {
		class_2960 texture = getTexture();
		if (texture == null) {
			return;
		}

		int glowColor = ColorUtil.withAlpha(color, alpha);
		float textureSize = scale * 0.5F;
		int r = glowColor >> 16 & 0xFF;
		int g = glowColor >> 8 & 0xFF;
		int b = glowColor & 0xFF;
		int a = (int) (255 * alpha);

		matrices.method_22903();
		matrices.method_46416(relX, relY, relZ);
		matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
		matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));

		if (spinning) {
			matrices.method_22907(class_7833.field_40718.rotationDegrees(rotation));
		}

		Matrix4f matrix = matrices.method_23760().method_23761();
		class_1921 layer = ParticleRenderLayers.GLOW.apply(texture);
		class_4588 buffer = vertexConsumers.method_73477(layer);
		float half = textureSize / 2.0F;

		buffer.method_22918(matrix, -half, -half, 0).method_22913(0, 0).method_1336(r, g, b, a);
		buffer.method_22918(matrix, -half, half, 0).method_22913(0, 1).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, half, 0).method_22913(1, 1).method_1336(r, g, b, a);
		buffer.method_22918(matrix, half, -half, 0).method_22913(1, 0).method_1336(r, g, b, a);
		matrices.method_22909();

		matrices.method_22903();
		matrices.method_46416(relX, relY, relZ);
		matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
		matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
		Matrix4f glowMatrix = matrices.method_23760().method_23761();

		float glowSizePrimary = textureSize * glowSize * 0.5F;
		float glowSizeSecondary = textureSize * glowSize * 0.2F;
		renderGlow(vertexConsumers, glowMatrix, glowColor, alpha, glowSizePrimary, glowSizeSecondary);
		matrices.method_22909();
	}

	private void renderGlow(class_4597 vertexConsumers, Matrix4f matrix, int glowColor, float alpha, float sizePrimary, float sizeSecondary) {
		if (glowMode == GlowMode.BLOOM || glowMode == GlowMode.BOTH) {
			ParticleRenderer.drawGlow(vertexConsumers.method_73477(ParticleRenderLayers.GLOW.apply(GLOW_BLOOM)), matrix, glowColor, (int) (80.0F * alpha), sizePrimary);
		}

		if (glowMode == GlowMode.BLOOM_SAMPLE || glowMode == GlowMode.BOTH) {
			ParticleRenderer.drawGlow(vertexConsumers.method_73477(ParticleRenderLayers.GLOW.apply(GLOW_BLOOM_SAMPLE)), matrix, glowColor, (int) (140.0F * alpha), sizeSecondary);
		}
	}
}
