package particle.fx.particle;

import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ParticleSettingsScreen extends class_437 {
	private static final int BUTTON_HEIGHT = 20;
	private static final int BUTTON_WIDTH = 150;
	private static final int GAP = 8;

	private final class_437 parent;
	private final ParticleSystem.Settings settings;
	private Tab tab = Tab.EVENTS;

	public ParticleSettingsScreen(class_437 parent) {
		super(class_2561.method_43470("Visual Particle Better Settings"));
		this.parent = parent;
		this.settings = ParticleSystem.getInstance().getSettings();
	}

	@Override
	protected void method_25426() {
		rebuildWidgets();
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		context.method_25294(0, 0, field_22789, field_22790, 0x66000000);
		context.method_27534(field_22793, field_22785, field_22789 / 2, 16, 0xFFFFFF);
		super.method_25394(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	@Override
	public void method_25419() {
		if (field_22787 != null) {
			field_22787.method_1507(parent);
		}
	}

	private void rebuildWidgets() {
		method_37067();

		int fullWidth = Math.min(320, field_22789 - 40);
		int left = (field_22789 - fullWidth) / 2;
		int right = left + fullWidth / 2 + GAP / 2;
		int halfWidth = (fullWidth - GAP) / 2;
		int y = 40;

		method_37063(button(left, y, halfWidth, labelTab(Tab.EVENTS), button -> {
			tab = Tab.EVENTS;
			rebuildWidgets();
		}));
		method_37063(button(right, y, halfWidth, labelTab(Tab.WORLD), button -> {
			tab = Tab.WORLD;
			rebuildWidgets();
		}));

		y += 26;
		method_37063(toggle(left, y, halfWidth, "Enabled", () -> settings.enabled, value -> settings.enabled = value));
		method_37063(toggle(right, y, halfWidth, "Random Color", () -> settings.randomColor, value -> settings.randomColor = value));

		y += 28;
		if (tab == Tab.EVENTS) {
			addEventWidgets(left, right, y, fullWidth, halfWidth);
		} else {
			addWorldWidgets(left, right, y, fullWidth, halfWidth);
		}

		int bottomY = field_22790 - 28;
		method_37063(button(field_22789 / 2 - BUTTON_WIDTH - 4, bottomY, BUTTON_WIDTH, class_2561.method_43470("Reset"), button -> {
			settings.reset();
			rebuildWidgets();
		}));
		method_37063(button(field_22789 / 2 + 4, bottomY, BUTTON_WIDTH, class_2561.method_43470("Done"), button -> method_25419()));
	}

	private void addEventWidgets(int left, int right, int y, int fullWidth, int halfWidth) {
		method_37063(button(left, y, halfWidth, () -> "Mode: " + clean(settings.particleMode.name()), button -> {
			settings.particleMode = next(settings.particleMode);
			button.method_25355(class_2561.method_43470("Mode: " + clean(settings.particleMode.name())));
		}));
		method_37063(button(right, y, halfWidth, () -> "Glow: " + clean(settings.glowMode.name()), button -> {
			settings.glowMode = next(settings.glowMode);
			button.method_25355(class_2561.method_43470("Glow: " + clean(settings.glowMode.name())));
		}));

		y += 26;
		method_37063(toggle(left, y, halfWidth, "Attack", () -> settings.attackTrigger, value -> settings.attackTrigger = value));
		method_37063(toggle(right, y, halfWidth, "Totem", () -> settings.totemTrigger, value -> settings.totemTrigger = value));

		y += 24;
		method_37063(toggle(left, y, halfWidth, "Walk", () -> settings.walkTrigger, value -> settings.walkTrigger = value));
		method_37063(toggle(right, y, halfWidth, "Projectiles", () -> settings.projectileTrigger, value -> settings.projectileTrigger = value));

		y += 32;
		method_37063(slider(left, y, fullWidth, "Attack Amount", 10, 80, () -> settings.attackAmount, value -> settings.attackAmount = (int) Math.round(value), value -> Integer.toString((int) Math.round(value))));
		y += 24;
		method_37063(slider(left, y, fullWidth, "Walk Amount", 0, 60, () -> settings.walkAmount, value -> settings.walkAmount = (int) Math.round(value), value -> Integer.toString((int) Math.round(value))));
		y += 24;
		method_37063(slider(left, y, fullWidth, "Spread", 0.2, 3.0, () -> settings.spread, value -> settings.spread = value.floatValue(), ParticleSettingsScreen::format));
		y += 24;
		method_37063(slider(left, y, fullWidth, "Speed", 0.1, 4.0, () -> settings.speed, value -> settings.speed = value.floatValue(), ParticleSettingsScreen::format));
		y += 24;
		method_37063(slider(left, y, fullWidth, "Life", 0.3, 8.0, () -> settings.lifeTime, value -> settings.lifeTime = value.floatValue(), value -> format(value) + "s"));
		y += 24;
		method_37063(slider(left, y, fullWidth, "Size", 0.2, 2.0, () -> settings.size, value -> settings.size = value.floatValue(), ParticleSettingsScreen::format));
	}

	private void addWorldWidgets(int left, int right, int y, int fullWidth, int halfWidth) {
		method_37063(toggle(left, y, halfWidth, "World Particles", () -> settings.worldParticles, value -> settings.worldParticles = value));
		method_37063(toggle(right, y, halfWidth, "World Physics", () -> settings.worldPhysics, value -> settings.worldPhysics = value));

		y += 28;
		method_37063(button(left, y, halfWidth, () -> "World Mode: " + clean(settings.worldMode.name()), button -> {
			settings.worldMode = next(settings.worldMode);
			button.method_25355(class_2561.method_43470("World Mode: " + clean(settings.worldMode.name())));
		}));
		method_37063(button(right, y, halfWidth, () -> "Glow: " + clean(settings.glowMode.name()), button -> {
			settings.glowMode = next(settings.glowMode);
			button.method_25355(class_2561.method_43470("Glow: " + clean(settings.glowMode.name())));
		}));

		y += 34;
		method_37063(slider(left, y, fullWidth, "World Amount", 10, 500, () -> settings.worldAmount, value -> settings.worldAmount = (int) Math.round(value), value -> Integer.toString((int) Math.round(value))));
		y += 26;
		method_37063(slider(left, y, fullWidth, "World Life", 2.0, 60.0, () -> settings.worldLifeTime, value -> settings.worldLifeTime = value.floatValue(), value -> format(value) + "s"));
		y += 26;
		method_37063(slider(left, y, fullWidth, "World Size", 0.1, 1.5, () -> settings.worldSize, value -> settings.worldSize = value.floatValue(), ParticleSettingsScreen::format));
		y += 26;
		method_37063(slider(left, y, fullWidth, "World Glow", 0.1, 8.0, () -> settings.worldGlowSize, value -> settings.worldGlowSize = value.floatValue(), ParticleSettingsScreen::format));
		y += 26;
		method_37063(slider(left, y, fullWidth, "Event Glow", 0.5, 12.0, () -> settings.glowSize, value -> settings.glowSize = value.floatValue(), ParticleSettingsScreen::format));
	}

	private class_4185 toggle(int x, int y, int width, String label, BooleanSupplier getter, Consumer<Boolean> setter) {
		return button(x, y, width, () -> label + ": " + (getter.getAsBoolean() ? "ON" : "OFF"), button -> {
			setter.accept(!getter.getAsBoolean());
			button.method_25355(class_2561.method_43470(label + ": " + (getter.getAsBoolean() ? "ON" : "OFF")));
		});
	}

	private class_4185 button(int x, int y, int width, class_2561 label, class_4185.class_4241 action) {
		return class_4185.method_46430(label, action).method_46434(x, y, width, BUTTON_HEIGHT).method_46431();
	}

	private class_4185 button(int x, int y, int width, Supplier<String> label, class_4185.class_4241 action) {
		return button(x, y, width, class_2561.method_43470(label.get()), action);
	}

	private SettingSlider slider(int x, int y, int width, String label, double min, double max, DoubleSupplier getter, Consumer<Double> setter, DoubleFunction<String> formatter) {
		return new SettingSlider(x, y, width, BUTTON_HEIGHT, label, min, max, getter, setter, formatter);
	}

	private class_2561 labelTab(Tab value) {
		String label = value == Tab.EVENTS ? "Event Particles" : "Particle World";
		if (tab == value) {
			return class_2561.method_43470("> " + label + " <");
		}
		return class_2561.method_43470(label);
	}

	private static Particle3D.ParticleMode next(Particle3D.ParticleMode mode) {
		Particle3D.ParticleMode[] values = Particle3D.ParticleMode.values();
		return values[(mode.ordinal() + 1) % values.length];
	}

	private static Particle3D.GlowMode next(Particle3D.GlowMode mode) {
		Particle3D.GlowMode[] values = Particle3D.GlowMode.values();
		return values[(mode.ordinal() + 1) % values.length];
	}

	private static String clean(String value) {
		return value.toLowerCase(Locale.ROOT).replace('_', ' ');
	}

	private static String format(double value) {
		return String.format(Locale.ROOT, "%.1f", value);
	}

	private enum Tab {
		EVENTS,
		WORLD
	}

	private static class SettingSlider extends class_357 {
		private final String label;
		private final double min;
		private final double max;
		private final Consumer<Double> setter;
		private final DoubleFunction<String> formatter;

		SettingSlider(int x, int y, int width, int height, String label, double min, double max, DoubleSupplier getter, Consumer<Double> setter, DoubleFunction<String> formatter) {
			super(x, y, width, height, class_2561.method_43473(), normalize(getter.getAsDouble(), min, max));
			this.label = label;
			this.min = min;
			this.max = max;
			this.setter = setter;
			this.formatter = formatter;
			method_25346();
		}

		@Override
		protected void method_25346() {
			method_25355(class_2561.method_43470(label + ": " + formatter.apply(value())));
		}

		@Override
		protected void method_25344() {
			setter.accept(value());
		}

		private double value() {
			return min + (max - min) * field_22753;
		}

		private static double normalize(double value, double min, double max) {
			return Math.max(0.0, Math.min(1.0, (value - min) / (max - min)));
		}
	}
}
