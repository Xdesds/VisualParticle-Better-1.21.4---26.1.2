package particle.fx;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.fabricmc.api.ClientModInitializer;
import org.lwjgl.glfw.GLFW;
import particle.fx.particle.ParticleSettingsScreen;
import particle.fx.particle.ParticleSystem;

public class ParticleFxClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ParticleSystem particles = ParticleSystem.getInstance();
		class_304 settingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.visualparticle-better.settings",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				class_304.class_11900.field_62556
		));

		ClientTickEvents.END_CLIENT_TICK.register(particles::tick);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (settingsKey.method_1436()) {
				client.method_1507(new ParticleSettingsScreen(client.field_1755));
			}
		});
		WorldRenderEvents.AFTER_ENTITIES.register(particles::render);
	}
}
