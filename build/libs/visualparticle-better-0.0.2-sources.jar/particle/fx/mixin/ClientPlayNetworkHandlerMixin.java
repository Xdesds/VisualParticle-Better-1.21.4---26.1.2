package particle.fx.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_2663;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import particle.fx.particle.ParticleSystem;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {
	@Inject(method = "onEntityStatus", at = @At("HEAD"))
	private void particleFx$onEntityStatus(class_2663 packet, CallbackInfo ci) {
		if (packet.method_11470() != 35) {
			return;
		}

		class_310 client = class_310.method_1551();
		if (client.field_1687 == null) {
			return;
		}

		class_1297 entity = packet.method_11469(client.field_1687);
		if (entity != null) {
			ParticleSystem.getInstance().spawnTotemParticles(entity);
		}
	}
}
